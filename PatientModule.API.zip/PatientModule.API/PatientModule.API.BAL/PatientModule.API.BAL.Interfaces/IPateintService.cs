﻿using PatientModule.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PatientModule.API.PatientModule.API.BAL.PatientModule.API.BAL.Interfaces
{
    public interface IPateintService<T> where T:class
    {
        IEnumerable<T> GetAll();
    }
}
